﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace sample {
    public partial class Form1 : DevExpress.XtraEditors.XtraForm {
        public Form1() {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e) {
            UserControl1 uc = GetUserControl();
            Controls.Add(uc);
        }
        private static UserControl1 GetUserControl() {
            UserControl1 uc = new UserControl1();
            uc.Location = new Point(100, 100);
            return uc;
        }
    }
}
